import numpy as np
import os
import ETcal
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import datetime
os.chdir('H:\MOD17\P-LSH model') #import the data
df = pd.read_excel('CA-NS5.xls')
Tmin = df.Tmin.tolist()
Tavg = df.Tavg.tolist()
Tmax = df.Tmax.tolist()
VPD = df.VPD.tolist()
WS = df.WS.tolist()
Rn = df.Rn.tolist()
Tday = df.Tday.tolist()
Pres = df.PA.tolist()
CO2 = df.CO2.tolist()
NDVI= df.NDVI.tolist()
LWobs=df.LWobs.tolist()

ETsm=[]
ETobs=[]
a= ETcal.initialize() 
for i in range(0,len(Tmin)):
 LE=a.ETcal(Tmin[i],Tavg[i],Tmax[i],VPD[i],WS[i],Rn[i],Tday[i],Pres[i],CO2[i],NDVI[i],0)#Calculate the latent heat flux
 ET= LE*0.03527; # convert to the evaporation
 ETobssite=LWobs[i]*0.03527;  
 ETsm.append(ET) 
 ETobs.append( ETobssite)   
a.terminate()
fig, host = plt.subplots()  
host.grid(False)
#
host.xaxis.set_major_formatter(mdates.DateFormatter("%y/%m"))
host.xaxis.set_minor_locator(mdates.MonthLocator())
host.tick_params(axis = "both", direction = "out", labelsize = 10)
date1 = datetime.date(2002, 1, 1)
date2 = datetime.date(2006, 1, 1)
delta = datetime.timedelta(days =1)
dates = mdates.drange(date1, date2, delta)
A,=host.plot_date(dates,  ETobs, '.',color='black', alpha = 0.5,label='$\mathregular{ET_{EC}}}$')
B,=host.plot_date(dates, ETsm,'k-',linewidth =1.0, alpha = 1.0,label='$\mathregular{ET_{sm}}}$')
fig.autofmt_xdate()
plt.text(11688.5,3.6,'CA-NS5',fontsize=15)
plt.ylabel('$\mathregular{ET}}$ (mm)')
plt.xlabel('Date(YY/MM)')
plt.ylim((0,4));
legend=plt.legend(handles=[A, B])
plt.tight_layout()
#plt.savefig('H:/MOD17/test2.png',dpi=600, bbox_inches='tight') #save the figure
plt.show()
